﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Controller : MonoBehaviour {

    public float MaxSpeed = 10f;
    public float speed = 2f;
    public bool grounded;
    public float jumpPower = 6.5f;

    private Rigidbody2D rb2d;
    private Animator anim;
    private bool Jump;

    // Use this for initialization
    void Start () {
        rb2d = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        anim.SetFloat("Speed", Mathf.Abs(rb2d.velocity.x)); //por direcciones en x valor absoluto en las condiciones de animator
        anim.SetBool("Grounded", grounded);

        if (Input.GetKeyDown(KeyCode.UpArrow) && anim.GetBool("Grounded") == true)
        {
            Jump = true;
        }
	}

    void FixedUpdate()
    {
        Vector3 fixedVelocity = rb2d.velocity;
        fixedVelocity.x *= 0.75f;

        if (grounded)
        {
            rb2d.velocity = fixedVelocity;
        }

        float horizontal = Input.GetAxis("Horizontal");

        rb2d.AddForce(Vector2.right * speed * horizontal);

        float limitedSpeed = Mathf.Clamp(rb2d.velocity.x, -MaxSpeed, MaxSpeed);
        rb2d.velocity = new Vector2(limitedSpeed, rb2d.velocity.y);
        /*Caso no optimo!
        //caso derecha
        if(rb2d.velocity.x > MaxSpeed){
            rb2d.velocity = new Vector2(MaxSpeed, rb2d.velocity.y);
        }
        //caso izquierda
        if (rb2d.velocity.x < -MaxSpeed)
        {
            rb2d.velocity = new Vector2(-MaxSpeed, rb2d.velocity.y);
        }
        */

        if(horizontal > 0.1f)
        {
            transform.localScale = new Vector3(1f, 1f, 1f);
        }

        if(horizontal < -0.1f)
        {
            transform.localScale = new Vector3(-1f, 1f, 1f);
        }

        if(Jump) {
            rb2d.velocity = new Vector2(rb2d.velocity.x, 0);
            rb2d.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
            Jump = false;
        }
        //Debug.Log(rb2d.velocity.x);
    }

    private void OnBecameInvisible()
    {
        transform.position = new Vector3(-10, 0, 0);
    }
}
